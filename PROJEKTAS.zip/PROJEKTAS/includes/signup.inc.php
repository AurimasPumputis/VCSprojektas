<?php
    if (isset($_POST['submit'])) {
        include_once 'db.inc.php';
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $pwd = mysqli_real_escape_string($conn, $_POST['pwd']);
        $pwd_confirm = mysqli_real_escape_string($conn, $_POST['pwd_confirm']);
        // Error handlers
        // Patikriname ar yra tuščių laukelių
        if(empty($email) || empty($pwd)) {
            header("Location: ../signup.php?signup=empty");
            exit();
        } else {
            // Patikriname ar galiojantis email formatas
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                header("Location: ../signup.php?signup=invalidemail");
                exit();
            } else {
                // Patikriname ar email jau naudojamas
                $sql = "SELECT * FROM users WHERE user_email = '$email'";
                $result = mysqli_query($conn, $sql);
                $result_check = mysqli_num_rows($result);
                if ($result_check > 0) {
                    header("Location: ../signup.php?signup=emailtaken");
                    exit();
                } else {
                    // Patikriname ar slaptažodžiai sutampa
                    if ($pwd != $pwd_confirm) {
                        header("Location: ../signup.php?signup=pwddoesnotmatch");
                        exit();
                    } else {
                        // Sukuriame hash slaptažodžiui
                        $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
                        // Įkeliame vartotoją į DB
                        $sql = "INSERT INTO users (user_email, user_pwd) VALUES('$email', '$hashedPwd')";
                        mysqli_query($conn, $sql);
                        header("Location: ../index.php?signup=success");
                        exit();
                    }
                }
            }
        }
    } else {
        header("Location: ../signup.php");
        exit();
    }
