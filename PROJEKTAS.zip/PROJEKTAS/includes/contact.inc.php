<?php
    if (isset($_POST['submit'])) {
        include('db.inc.php');

        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $message = mysqli_real_escape_string($conn, $_POST['message']);

        if(!empty($name) && !empty($email) && !empty($message)) {
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $to = "aurimassp@gmail.com";
                $subject = "New message";
                $user = 'FROM: ' . $name . ', ' . $email;
                mail($to, $subject, $user, $message, $email);

                mysqli_query($conn, "INSERT INTO messages (name, email, message) VALUES('$name', '$email', '$message')");

                header("Location: ../contact.php?message=sent");
                exit();
            }
        }

    }
?>
