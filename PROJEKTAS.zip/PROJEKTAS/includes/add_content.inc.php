<?php
	if (isset($_POST['submit'])) {
        include_once 'db.inc.php';
        $type = mysqli_real_escape_string($conn, $_POST['type']);
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $poster = $_FILES['poster'];
        $rating = mysqli_real_escape_string($conn, $_POST['rating']);
        $published = mysqli_real_escape_string($conn, $_POST['published']);
        $genre = mysqli_real_escape_string($conn, $_POST['genre']);
        $storyline = mysqli_real_escape_string($conn, $_POST['storyline']);

        // ERROR HANDLERS

        // Tikriname ar yra tuščių laukelių
        if (empty($type) || empty($title) || empty($poster) || empty($rating) || empty($published) || empty($genre) || empty($storyline)) {
        	header("Location: ../settings.php?add_content=empty");
            exit();
        } else {
        	if ($type == "movie") {
        		$poster_path = 'uploads/Movies/' . $title . '/' . basename($poster["name"]);
        		$target_file = '../' . $poster_path;
        		mkdir('../uploads/Movies/' . $title);
        		move_uploaded_file($poster["tmp_name"], $target_file);

	        	$sql = "INSERT INTO movies (movie_title, movie_poster, movie_rating, movie_published, movie_genre, movie_storyline) VALUES('$title', '$poster_path', '$rating', '$published', '$genre', '$storyline');";
	            mysqli_query($conn, $sql);
	            header("Location: ../settings.php?add_content=success");
	            exit();
        	} elseif ($type == "tv-show") {
        		$poster_path = 'uploads/TV/' . $title . '/' . basename($poster["name"]);
        		$target_file = '../' . $poster_path;
        		mkdir('../uploads/TV/' . $title);
        		move_uploaded_file($poster["tmp_name"], $target_file);

        		$sql = "INSERT INTO tvshows (tv_title, tv_poster, tv_rating, tv_published, tv_genre, tv_storyline) VALUES('$title', '$poster_path', '$rating', '$published', '$genre', '$storyline');";
	            mysqli_query($conn, $sql);
	            header("Location: ../settings.php?add_content=success");
	            exit();
        	}
        }

    } else {
    	header("Location: ../settings.php");
        exit();
    }