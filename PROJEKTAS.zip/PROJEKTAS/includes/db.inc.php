<?php
    define("DB_SERVER", "localhost");
    define("DB_USER", "root");
    define("DB_PASSWORD", "");
    define("DB_NAME", "movieStore");

    $conn = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
    if ($conn->connect_error) {
        echo "Atsiprašome, bet svetainė susidūrė su problema.\n";
        echo 'Error: ' . $conn->connect_error . '\n';
        exit();
    }