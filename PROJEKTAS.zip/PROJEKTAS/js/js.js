/// Tekstas po navigacijos ikonelem
function showNavText(icon, text) {
    let nav_item = document.getElementById(icon);
    let nav_text = document.getElementById(text);

    nav_item.addEventListener("mouseenter", function () {
        nav_text.classList.add("nav-text-visible");
    });

    nav_item.addEventListener("mouseleave", function () {
        nav_text.classList.remove("nav-text-visible");
    });
}

showNavText('nav-home', 'nav-home-text');
showNavText('nav-movies', 'nav-movies-text');
showNavText('nav-tv', 'nav-tv-text');
showNavText('nav-lists', 'nav-lists-text');
showNavText('nav-contact', 'nav-contact-text');
if (document.getElementById('nav-register')) {
    showNavText('nav-register', 'nav-register-text');
    showNavText('nav-login', 'nav-login-text');
} else if (document.getElementById('nav-logout')) {
    showNavText('nav-logout', 'nav-logout-text');
    showNavText('nav-settings', 'nav-settings-text');
}
/// login langas paspaudus navigacijoj

function nav_event(event, action) {
    let screen = document.getElementById(event + "-content");
    let text = document.getElementById("nav-" + event + "-text");
    let option = document.getElementById("nav-" + event);

    if (action == "hide") {
        text.classList.remove("nav-login-reg-visible");
        option.classList.remove("nav-icon-red");
        screen.classList.add("hide");
        screen.classList.remove("show");
    } else if (action == "show") {
        text.classList.add("nav-login-reg-visible");
        option.classList.add("nav-icon-red");
        screen.classList.add("show");
        screen.classList.remove("hide");
    }
}
if (document.getElementById("nav-login")) {
    let nav_login = document.getElementById("nav-login");

    nav_login.addEventListener("click", function () {
        let login_screen = document.getElementById("login-content");
        let login_text = document.getElementById("nav-login-text");

        if (login_screen.classList.contains("hide")) {
            nav_event("login", "show");
            if (document.getElementById("register-content").classList.contains("show")) {
                nav_event("register", "hide");
            }

        } else {
            nav_event("login", "hide");
        }
    });
}

/// login langas paspaudus navigacijoj
if (document.getElementById("nav-register")) {
    let nav_reg = document.getElementById("nav-register");

    nav_reg.addEventListener("click", function () {
        let reg_screen = document.getElementById("register-content");
        let reg_text = document.getElementById("nav-register-text");

        if (reg_screen.classList.contains("hide")) {
            nav_event("register", "show");
            if (document.getElementById("login-content").classList.contains("show")) {
                nav_event("login", "hide");
            }

        } else {
            nav_event("register", "hide");
        }
    });
}

///Pagalbine f-ja, kuri patikrina ar css failas yra uzlaudintas
function isCssLoaded(filename) {
    let link_tags = document.getElementsByTagName("link");
    for (let i = 0; i < link_tags.length; i++) {
        let href = link_tags[i].href.split("/");
        let file = href[href.length-1];
        if (file == filename) {
            return true;
        }
    }
    return false;
}

/// Paspaudus ant burgerio prideda css faila, kuris sukuria navigacija
let nav_burger = document.getElementById("burger-icon");

nav_burger.addEventListener("click", function () {
    if (isCssLoaded("burger.css")) {
        let burger_css = document.getElementById("burger-css");
        burger_css.parentNode.removeChild(burger_css);
    } else {
        let head = document.getElementsByTagName("head")[0];
        let link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = "css/burger.css";
        link.id = "burger-css";
        head.appendChild(link);

    }
});

/// Admin area navigacija
let current_url = window.location.href.split("/");

if (current_url[current_url.length-1] == "settings.php" && document.getElementById("admin-settings")) {

    let add_content = document.getElementById("add-content");
    let user_list = document.getElementById("user-list");
    let user_settings = document.getElementById("admin-settings");
    let admin_list = [add_content, user_list, user_settings];
    let admin_nav = document.getElementById("admin-nav").children;

    function adminNavColor(el) {
        for (let i = 0; i < admin_nav.length; i++) {
            if (admin_nav[i].id == el) {
                admin_nav[i].children[0].classList.add("nav-text-color");
            } else {
                admin_nav[i].children[0].classList.remove("nav-text-color");
            }
        }
    }

    function adminNavClick(listener, active_content, hide_1, hide_2) {
        let nav_el = document.getElementById(listener).children[0];

        nav_el.addEventListener("click", function() {
            adminNavColor(listener);
            active_content.classList.remove("admin-hide");
            hide_1.classList.add("admin-hide");
            hide_2.classList.add("admin-hide");
        });
    }

    adminNavClick("admin-nav-add", add_content, user_list, user_settings);
    adminNavClick("admin-nav-users", user_list, add_content, user_settings);
    adminNavClick("admin-nav-settings", user_settings, user_list, add_content);
}
