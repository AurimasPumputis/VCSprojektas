$(document).ready(function () {
    function visible_nav_text(icon, text) {
        $(icon).hover(
            function () {
                $(text).addClass('nav-text-visible');
            }, function() {
                $(text).removeClass('nav-text-visible');
            }
        );
    }

    visible_nav_text('#nav-home', '#nav-home-text');
    visible_nav_text('#nav-movies', '#nav-movies-text');
    visible_nav_text('#nav-tv', '#nav-tv-text');
    visible_nav_text('#nav-lists', '#nav-lists-text');
    visible_nav_text('#nav-contact', '#nav-contact-text');
    visible_nav_text('#nav-register', '#nav-register-text');
    visible_nav_text('#nav-login', '#nav-login-text');

    $('#nav-login').click(function () {
        $('#login-content').fadeToggle();
        if($('#login-content').css('display') != 'none') { 
            $('#nav-login').unbind('mouseenter mouseleave');
            $('#nav-login').css('color', '#cb2a31');
            console.log($('#login-content').css('display'));
        } else {
            console.log($('#login-content').css('display'));
            visible_nav_text('#nav-login', '#nav-login-text');
            $('#nav-login').css('color', '#575c67');
        }
    });
});